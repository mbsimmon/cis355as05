<head>
    <meta charset="utf-8"><link href="../css/bootstrap.min.css" rel="stylesheet">
    <script src="../js/bootstrap.min.js">
    </script>
</head>

<?php
class Functions {
    
    function output_html_head() {
        echo '<head><meta charset="utf-8"><link href="css/bootstrap.min.css" rel="stylesheet"><script src="js/bootstrap.min.js"></script></head>';
    }
    
}

?>